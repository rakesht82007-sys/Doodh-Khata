# Doodh Khata Android project

A separate Android milk-ordering and monthly khata app.

## Defaults
- Regular milk: ₹76/L
- Cow milk: ₹84/L
- WhatsApp recipient: +91 8976628887
- Orders are dated for tomorrow.

## Build with GitHub Actions (phone-friendly)
1. Create a NEW GitHub repository named `Doodh-Khata` (do not replace the Cold Storage repository).
2. Upload the contents of this ZIP into the repository root, preserving `.github/workflows/build-apk.yml`.
3. Open Actions → Build Doodh Khata APK → Run workflow (or wait for the push build).
4. Open the successful run, download artifact `Doodh-Khata-APK`, extract it, and install `app-debug.apk`.

The app uses an on-device SQLite database. Keep a CSV export copy periodically. WhatsApp opens with the order text ready; you must tap Send in WhatsApp.
