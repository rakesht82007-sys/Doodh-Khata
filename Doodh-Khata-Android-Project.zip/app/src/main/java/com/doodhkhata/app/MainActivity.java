package com.doodhkhata.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import androidx.core.content.FileProvider;
import java.io.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    DB db; LinearLayout page, root; EditText regular, cow, phone, rateRegular, rateCow;
    TextView summary; String blue="#1976D2"; int pad=16;
    public void onCreate(Bundle b){ super.onCreate(b); db=new DB(this); showHome(); }
    int dp(float x){return (int)(x*getResources().getDisplayMetrics().density);}
    TextView text(String s,int size,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.rgb(35,45,55)); if(bold)t.setTypeface(null,1); t.setPadding(0,dp(5),0,dp(5)); return t; }
    EditText input(String hint,String value){ EditText e=new EditText(this); e.setSingleLine(true); e.setText(value); e.setHint(hint); e.setTextSize(16); return e; }
    Button button(String s,Runnable r){ Button b=new Button(this); b.setText(s); b.setAllCaps(false); b.setOnClickListener(v->r.run()); return b; }
    void base(String title){ root=new LinearLayout(this); root.setOrientation(1); root.setBackgroundColor(Color.rgb(246,249,252)); ScrollView sc=new ScrollView(this); page=new LinearLayout(this); page.setOrientation(1); page.setPadding(dp(pad),dp(12),dp(pad),dp(28)); sc.addView(page); root.addView(sc); setContentView(root); page.addView(text("🥛 "+title,25,true)); }
    String todayPlus(int n){ Calendar c=Calendar.getInstance(); c.add(Calendar.DAY_OF_YEAR,n); return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime()); }
    String money(double x){return "₹"+String.format(Locale.US,"%.2f",x);}
    void showHome(){
        base("Doodh Khata");
        page.addView(text("Daily milk order · Delivery date: "+todayPlus(1),16,true));
        regular=input("Regular Milk (litres)",""); cow=input("Cow Milk (litres)",""); regular.setInputType(8194); cow.setInputType(8194);
        page.addView(text("Regular Milk (L)",14,true)); page.addView(regular); page.addView(text("Cow Milk (L)",14,true)); page.addView(cow);
        page.addView(button("SAVE TOMORROW'S ORDER",()->saveOrder()));
        page.addView(button("SEND ORDER ON WHATSAPP",()->sendWhatsApp()));
        page.addView(button("Monthly bill & date-wise records",()->showBills()));
        page.addView(button("Rates and WhatsApp settings",()->showSettings()));
        page.addView(button("Consumption charts",()->showCharts()));
        page.addView(button("Export monthly CSV / PDF",()->chooseExport()));
        page.addView(button("Backup database (CSV)",()->exportCsv(true)));
        Cursor c=db.getReadableDatabase().rawQuery("SELECT COUNT(*),COALESCE(SUM(reg_qty),0),COALESCE(SUM(cow_qty),0) FROM orders",null);
        if(c.moveToFirst()) page.addView(text("Saved records: "+c.getInt(0)+"  ·  Regular: "+c.getDouble(1)+" L  ·  Cow: "+c.getDouble(2)+" L",14,false)); c.close();
    }
    void saveOrder(){
        double r=val(regular), c=val(cow); if(r<0||c<0){msg("Enter valid non-negative quantities");return;}
        SQLiteDatabase w=db.getWritableDatabase(); String d=todayPlus(1);
        ContentValues v=new ContentValues(); v.put("date",d); v.put("reg_qty",r); v.put("cow_qty",c); v.put("payment","Unpaid");
        w.insertWithOnConflict("orders",null,v,SQLiteDatabase.CONFLICT_REPLACE); msg("Order saved for "+d); 
    }
    double val(EditText e){try{return Double.parseDouble(e.getText().toString().trim().isEmpty()?"0":e.getText().toString().trim());}catch(Exception x){return -1;}}
    String setting(String k,String def){Cursor c=db.getReadableDatabase().rawQuery("SELECT value FROM settings WHERE key=?",new String[]{k}); String s=def;if(c.moveToFirst())s=c.getString(0);c.close();return s;}
    void sendWhatsApp(){
        String d=todayPlus(1), num=setting("phone","918976628887").replaceAll("[^0-9]","");
        double r=val(regular),c=val(cow); if(r<0||c<0){msg("Enter valid quantities first");return;}
        // Save the same next-day order before opening WhatsApp.
        ContentValues saved=new ContentValues(); saved.put("date",d); saved.put("reg_qty",r); saved.put("cow_qty",c); saved.put("payment","Unpaid");
        db.getWritableDatabase().insertWithOnConflict("orders",null,saved,SQLiteDatabase.CONFLICT_REPLACE);
        String message="*DOODH KHATA – MILK ORDER*\\n\\n*Delivery Date:* "+d+"\\n──────────────────\\nRegular Milk: "+r+" Litres\\nCow Milk: "+c+" Litres\\n──────────────────\\nPlease confirm tomorrow's delivery. Thank you.";
        try{Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/"+num+"?text="+android.net.Uri.encode(message))); startActivity(i);}catch(Exception e){msg("WhatsApp could not be opened");}
    }
    void showSettings(){
        base("Rates & WhatsApp settings");
        page.addView(text("Current rates (₹ per litre)",17,true));
        rateRegular=input("Regular Milk rate",setting("regular_rate","76")); rateCow=input("Cow Milk rate",setting("cow_rate","84"));
        rateRegular.setInputType(8194);rateCow.setInputType(8194);
        page.addView(text("Regular Milk",14,true));page.addView(rateRegular);page.addView(text("Cow Milk",14,true));page.addView(rateCow);
        EditText effective=input("Effective from (YYYY-MM-DD)",todayPlus(0)); page.addView(text("Rates apply from this date",14,true));page.addView(effective);
        EditText p=input("WhatsApp number with country code",setting("phone","918976628887"));p.setInputType(3);page.addView(text("WhatsApp recipient number",14,true));page.addView(p);
        page.addView(button("SAVE SETTINGS",()->{
            try{double rr=Double.parseDouble(rateRegular.getText().toString()),cc=Double.parseDouble(rateCow.getText().toString()); if(rr<0||cc<0)throw new Exception();
                db.set("phone",p.getText().toString().replaceAll("[^0-9]","")); 
                db.getWritableDatabase().execSQL("INSERT INTO rates(start_date,reg_rate,cow_rate) VALUES(?,?,?)",new Object[]{effective.getText().toString(),rr,cc});
                db.set("regular_rate",String.valueOf(rr));db.set("cow_rate",String.valueOf(cc));msg("Settings and dated rates saved");showSettings();
            }catch(Exception e){msg("Check rates and date format");}
        }));
        page.addView(button("Back",()->showHome()));
        page.addView(text("Changing a rate creates a new effective-date entry. Earlier dates continue using their historical rate.",13,false));
    }
    double[] rates(String date){
        Cursor c=db.getReadableDatabase().rawQuery("SELECT reg_rate,cow_rate FROM rates WHERE start_date<=? ORDER BY start_date DESC,id DESC LIMIT 1",new String[]{date});
        double[] a={Double.parseDouble(setting("regular_rate","76")),Double.parseDouble(setting("cow_rate","84"))};
        if(c.moveToFirst()){a[0]=c.getDouble(0);a[1]=c.getDouble(1);}c.close();return a;
    }
    void showBills(){
        base("Monthly bills");
        EditText month=input("Month (YYYY-MM)",new SimpleDateFormat("yyyy-MM",Locale.US).format(new Date()));
        page.addView(text("Select month (YYYY-MM)",14,true)); page.addView(month);
        page.addView(button("VIEW MONTHLY BILL",()->billRows(month.getText().toString())));
        page.addView(button("Back",()->showHome()));
    }
    void billRows(String m){
        if(!m.matches("\\d{4}-\\d{2}")){msg("Enter month as YYYY-MM");showBills();return;}
        base("Monthly bill · "+m);
        Cursor c=db.getReadableDatabase().rawQuery("SELECT date,reg_qty,cow_qty,payment FROM orders WHERE date LIKE ? ORDER BY date",new String[]{m+"%"});
        double tr=0,tc=0,ta=0;
        while(c.moveToNext()){
            String d=c.getString(0);double r=c.getDouble(1),co=c.getDouble(2);String payment=c.getString(3);
            double[] rt=rates(d);double amount=r*rt[0]+co*rt[1];tr+=r;tc+=co;ta+=amount;
            page.addView(text(d+"  | Regular "+r+" L @ "+money(rt[0])+" | Cow "+co+" L @ "+money(rt[1])+" | "+money(amount)+" | "+payment,14,false));
            final String date=d; final double rq=r,cq=co; final String pay=payment;
            page.addView(button("Edit "+d,()->editEntry(date,rq,cq,pay)));
        }
        c.close();
        page.addView(text("MONTH TOTAL",18,true));page.addView(text("Regular: "+tr+" L · Cow: "+tc+" L",16,true));page.addView(text("Total payable: "+money(ta),22,true));
        page.addView(button("Choose another month",()->showBills()));page.addView(button("Export this month (CSV)",()->exportMonth(m,false)));page.addView(button("Download / share PDF bill",()->exportPdf(m)));page.addView(button("Back",()->showHome()));
    }
    void editEntry(String d,double r,double c,String pay){
        LinearLayout box=new LinearLayout(this);box.setOrientation(1);
        EditText er=input("Regular litres",String.valueOf(r)), ec=input("Cow litres",String.valueOf(c)); Spinner sp=new Spinner(this);String[] opts={"Unpaid","Paid","Partially Paid"};sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,opts));sp.setSelection(Arrays.asList(opts).indexOf(pay));
        box.addView(er);box.addView(ec);box.addView(sp);
        new AlertDialog.Builder(this).setTitle("Edit "+d).setView(box).setPositiveButton("Save",(x,y)->{
            try{ContentValues v=new ContentValues();v.put("reg_qty",Double.parseDouble(er.getText().toString()));v.put("cow_qty",Double.parseDouble(ec.getText().toString()));v.put("payment",sp.getSelectedItem().toString());db.getWritableDatabase().update("orders",v,"date=?",new String[]{d});showBills();}catch(Exception e){msg("Invalid quantity");}
        }).setNegativeButton("Cancel",null).show();
    }
    void showCharts(){
        base("Consumption comparison");
        page.addView(text("Monthly quantities from saved records",15,true));
        Cursor c=db.getReadableDatabase().rawQuery("SELECT substr(date,1,7),SUM(reg_qty),SUM(cow_qty) FROM orders GROUP BY substr(date,1,7) ORDER BY 1 DESC LIMIT 12",null);
        ArrayList<String> labels=new ArrayList<>();ArrayList<Float> rr=new ArrayList<>(),cc=new ArrayList<>();
        while(c.moveToNext()){labels.add(c.getString(0));rr.add((float)c.getDouble(1));cc.add((float)c.getDouble(2));}
        c.close(); if(labels.isEmpty())page.addView(text("Charts will appear after you save orders.",14,false));
        else { Collections.reverse(labels);Collections.reverse(rr);Collections.reverse(cc); Chart chart=new Chart(this,labels,rr,cc);page.addView(chart,new LinearLayout.LayoutParams(-1,dp(260))); }
        page.addView(button("Back",()->showHome()));
    }
    class Chart extends View{
        ArrayList<String> l;ArrayList<Float>a,b;Paint p=new Paint(3);
        Chart(Context c,ArrayList<String>x,ArrayList<Float>y,ArrayList<Float>z){super(c);l=x;a=y;b=z;}
        protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight(),max=1;for(float v:a)max=Math.max(max,v);for(float v:b)max=Math.max(max,v);
            p.setColor(Color.LTGRAY);p.setStrokeWidth(2);c.drawLine(dp(28),h-dp(30),w-dp(8),h-dp(30),p);
            float slot=(w-dp(45))/Math.max(1,l.size());for(int i=0;i<l.size();i++){float x=dp(32)+i*slot;float ah=(h-dp(65))*a.get(i)/max,bh=(h-dp(65))*b.get(i)/max;
                p.setColor(Color.rgb(25,118,210));c.drawRect(x,h-dp(30)-ah,x+slot*.30f,h-dp(30),p);
                p.setColor(Color.rgb(67,160,71));c.drawRect(x+slot*.36f,h-dp(30)-bh,x+slot*.66f,h-dp(30),p);
                p.setColor(Color.DKGRAY);p.setTextSize(dp(9));c.drawText(l.get(i),x,h-dp(10),p);
            }
            p.setTextSize(dp(11));p.setColor(Color.rgb(25,118,210));c.drawText("Regular",dp(30),dp(15),p);p.setColor(Color.rgb(67,160,71));c.drawText("Cow milk",dp(100),dp(15),p);
        }
    }
    void chooseExport(){new AlertDialog.Builder(this).setTitle("Export monthly records").setItems(new String[]{"CSV / Excel-compatible","PDF bill"},(d,w)->{String m=new SimpleDateFormat("yyyy-MM",Locale.US).format(new Date());if(w==0)exportMonth(m,false);else exportPdf(m);}).show();}
    void exportCsv(boolean all){String m=new SimpleDateFormat("yyyy-MM",Locale.US).format(new Date());exportMonth(m,all);}
    void exportMonth(String m,boolean all){
        try{File f=new File(getExternalFilesDir(null),"DoodhKhata-"+(all?"backup":m)+".csv");PrintWriter out=new PrintWriter(new FileWriter(f));out.println("Date,Regular Qty L,Regular Rate,Cow Qty L,Cow Rate,Total Amount,Payment");
            Cursor c=db.getReadableDatabase().rawQuery("SELECT date,reg_qty,cow_qty,payment FROM orders "+(all?"":"WHERE date LIKE ? ")+"ORDER BY date",all?null:new String[]{m+"%"});
            while(c.moveToNext()){String d=c.getString(0);double r=c.getDouble(1),co=c.getDouble(2);double[] rt=rates(d);out.println(d+","+r+","+rt[0]+","+co+","+rt[1]+","+(r*rt[0]+co*rt[1])+","+c.getString(3));}c.close();out.close();shareFile(f,"text/csv");}
        catch(Exception e){msg("Export failed: "+e.getMessage());}
    }
    void exportPdf(String m){
        try{
            PdfDocument pdf=new PdfDocument(); Cursor cur=db.getReadableDatabase().rawQuery("SELECT date,reg_qty,cow_qty,payment FROM orders WHERE date LIKE ? ORDER BY date",new String[]{m+"%"});
            int pageNo=1,y=110; PdfDocument.Page pg=null; Canvas canvas=null; Paint p=new Paint(3); p.setColor(Color.BLACK); p.setTextSize(18);
            double total=0; int rows=0;
            while(cur.moveToNext()){
                if(pg==null || y>770){ if(pg!=null)pdf.finishPage(pg); PdfDocument.PageInfo pi=new PdfDocument.PageInfo.Builder(595,842,pageNo++).create();pg=pdf.startPage(pi);canvas=pg.getCanvas();p.setTextSize(18);canvas.drawText("DOODH KHATA – MILK BILL",40,50,p);p.setTextSize(12);canvas.drawText("Month: "+m+"  |  Date-wise statement",40,78,p);y=110; }
                String d=cur.getString(0);double r=cur.getDouble(1),co=cur.getDouble(2);double[] rt=rates(d);double amt=r*rt[0]+co*rt[1];total+=amt;rows++;
                p.setTextSize(10);canvas.drawText(d+"  Regular "+r+"L x "+rt[0]+"  Cow "+co+"L x "+rt[1]+"  "+money(amt)+"  "+cur.getString(3),40,y,p);y+=22;
            }
            cur.close();
            if(pg==null){PdfDocument.PageInfo pi=new PdfDocument.PageInfo.Builder(595,842,1).create();pg=pdf.startPage(pi);canvas=pg.getCanvas();p.setTextSize(18);canvas.drawText("DOODH KHATA – MILK BILL",40,50,p);p.setTextSize(12);canvas.drawText("No orders for "+m,40,90,p);}
            p.setTextSize(15);canvas.drawText("Total bill: "+money(total),40,810,p);pdf.finishPage(pg);
            File f=new File(getExternalFilesDir(null),"DoodhKhata-"+m+".pdf");FileOutputStream os=new FileOutputStream(f);pdf.writeTo(os);os.close();pdf.close();shareFile(f,"application/pdf");
        }catch(Exception e){msg("PDF export failed: "+e.getMessage());}
    }
    void shareFile(File f,String type){Uri u=FileProvider.getUriForFile(this,getPackageName()+".provider",f);Intent i=new Intent(Intent.ACTION_SEND);i.setType(type);i.putExtra(Intent.EXTRA_STREAM,u);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);try{startActivity(Intent.createChooser(i,"Share / Save report"));}catch(Exception e){msg("File saved in app storage: "+f.getAbsolutePath());}}
    Uri androidxUri(File f){return Uri.fromFile(f);}
    void msg(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    class DB extends SQLiteOpenHelper{
        DB(Context c){super(c,"doodhkhata.db",null,1);}
        public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE orders(date TEXT PRIMARY KEY,reg_qty REAL NOT NULL,cow_qty REAL NOT NULL,payment TEXT DEFAULT 'Unpaid')");d.execSQL("CREATE TABLE settings(key TEXT PRIMARY KEY,value TEXT)");d.execSQL("CREATE TABLE rates(id INTEGER PRIMARY KEY AUTOINCREMENT,start_date TEXT,reg_rate REAL,cow_rate REAL)");d.execSQL("INSERT INTO settings VALUES('phone','918976628887')");d.execSQL("INSERT INTO settings VALUES('regular_rate','76')");d.execSQL("INSERT INTO settings VALUES('cow_rate','84')");d.execSQL("INSERT INTO rates(start_date,reg_rate,cow_rate) VALUES('2000-01-01',76,84)");}
        public void onUpgrade(SQLiteDatabase d,int o,int n){}
        void set(String k,String v){ContentValues c=new ContentValues();c.put("key",k);c.put("value",v);getWritableDatabase().insertWithOnConflict("settings",null,c,SQLiteDatabase.CONFLICT_REPLACE);}
    }
}
